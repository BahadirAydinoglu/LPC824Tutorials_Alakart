


This project demonstrates the communication using the
UART asynchronous serial communication peripheral to the PC.

It is derived from the Simple print example and includes a simpler alternative to printf of 'C': "xprintf"

 xprintf is an open source project by ChaN. See:
http://elm-chan.org/fsw/strf/xprintf.html

It can work generally as the standard printf library function.


