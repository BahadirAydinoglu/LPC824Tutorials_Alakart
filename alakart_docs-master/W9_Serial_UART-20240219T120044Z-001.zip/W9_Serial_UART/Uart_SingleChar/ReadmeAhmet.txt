
This project demonstrates the communication using the
UART asynchronous serial communication peripheral to the PC.

Modern PC's do not have a serial port that will accept serial
communications. Therefore Alakart possesses a UART to USB converter chip (FT231XQ by FTDI company).

A serial port has two main connections: TX and RX.

TX: Transmit data. The data is sent out of this pin in a serial bit stream to another device.
RX: Receive data. The data is received into this pin in a serial bit stream from another device.

It has other connections to coordinate data transmission, but they are not discussed in this introductory text.

On Alakart, the UART to USB converter TX and RX pins are connected to:
UART to USB conv.    LPC824
TX   	    	     PIO0_0
RX		     PIO0_4

(note that UART to USB converter TX pin is an output, so PIO0_0 must be configured as an UART0 RX pin, and similarly,  UART to USB converter RX pin is an input, so PIO0_4 must be configured as an UART0 TX pin)

Therefore when initializing UART0 of LPC824 and connecting its TX and RX pins using SWM, we must make the connections as described above.




