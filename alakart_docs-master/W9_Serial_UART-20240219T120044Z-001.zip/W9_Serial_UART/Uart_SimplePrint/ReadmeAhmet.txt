


This project demonstrates the communication using the
UART asynchronous serial communication peripheral to the PC.

It is derived from the Singla character send program to implement a primitive "print over serial communications" function. Printf of the 'C' language works in a similar manner.


